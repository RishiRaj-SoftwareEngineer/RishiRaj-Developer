import React from 'react';
import '../Styling/DataLoader.css'

export  default function DataLoader() {

    return(
        <div className= "dataloading-layout">
            <span className="loader">L &nbsp; ading</span>
        </div>
    )
}
